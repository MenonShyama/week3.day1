package org.system;

public class Computer {
	//int number;
	
	public int computerModel(int number)
	{
		if(number==1)
		{
			System.out.println("Compuer model is HP");
		}
		if(number==2)
		{
			System.out.println("Compuer model is Lenovo");
		}
		return number;
		
	}
	

}

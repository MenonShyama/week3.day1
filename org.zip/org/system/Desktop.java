package org.system;

public class Desktop extends Computer{
	
	//int number;
	
	public void desktopSize(int number)
	{
		if(number==1)
		{
			System.out.println("Computer size is 45");
		}
		if(number==2)
		{
			System.out.println("Computer size is 56");
		}
		
	}
	
	public static void main(String[] args)
	{
		Desktop desk=new Desktop();
		desk.computerModel(1);
		desk.desktopSize(2);
				
	}

}

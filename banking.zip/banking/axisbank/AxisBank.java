package banking.axisbank;

import banking.bank.BankInfo;

public class AxisBank extends BankInfo{
	
	public void deposit()
	{
		System.out.println("Please Deposit");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AxisBank bank=new AxisBank();
		bank.saving();
		bank.fixed();
		bank.deposit();
	}

}

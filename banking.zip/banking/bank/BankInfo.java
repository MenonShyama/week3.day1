package banking.bank;

public class BankInfo {
	public void saving()
	{
		System.out.println("Saving Account");
	}
	public void fixed()
	{
		System.out.println("Fixed Deposit");
	}
	public void deposit()
	{
		System.out.println("Deposit Account");
	}
}

